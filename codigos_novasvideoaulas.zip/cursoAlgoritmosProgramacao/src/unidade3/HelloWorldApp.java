package unidade3;

import javax.swing.JOptionPane;

public class HelloWorldApp {

	public static void main(String[] args) {
		
		System.out.println("Alo Mundo!!!");
		JOptionPane.showMessageDialog(null, "Alo Mundo!!!");
	}

}
