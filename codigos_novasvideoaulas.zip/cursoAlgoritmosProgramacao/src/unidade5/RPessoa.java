package unidade5;

public record RPessoa(String nome, int idade) {

}
